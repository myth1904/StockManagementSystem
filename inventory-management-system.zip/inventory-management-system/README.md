
Need to change
core.php, logout.php, index.php
header('location: http://localhost/<foldername>/index.php');	

